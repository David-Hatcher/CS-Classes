public class Args 
{
	public static void main(String[] args)
	{	
		//Assuming the first argument is your name and
		//the second is your major:
		System.out.println("Your name is: " + args[0]);
		System.out.println("Your major is: " + args[1]);
		
		//System.out.println("Your name is: " + args[0] + "\nYour major is: " + args[1]);
	}
}