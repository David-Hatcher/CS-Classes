#ifndef SALES_TAX
#define SALES_TAX

#include <cmath>

namespace taxes{
    double getTax(double total);
    double getTotalPlusTax(double total);
}

#endif
