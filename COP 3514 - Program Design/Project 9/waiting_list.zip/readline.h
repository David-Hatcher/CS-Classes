#ifndef READ_LINE
#define READ_LINE


int read_line(char str[], int n);
#endif