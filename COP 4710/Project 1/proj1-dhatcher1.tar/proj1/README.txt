Running Instructions:

As this is written in python there is no need to compile.
To run the program type "python3 NBADB.py"
Please ensure that coaches.py, teams.py and NBADB.py are all in the same folder.
The load_coaches and load_teams uses relative path so you will need to adjust according for these functions.
