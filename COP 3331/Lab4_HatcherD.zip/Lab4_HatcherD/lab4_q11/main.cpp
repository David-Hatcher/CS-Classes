#include <iostream>
#include <array>
#include <string>
#include <limits>

using namespace std;

const char X_CHAR = 'X';//X player value
const char O_CHAR = 'O';//O player value
const string X_WINS = "XXX";//X wins string
const string O_WINS = "OOO";//O win string
const int LEN = 3;//length of arrays for board
const int SQUARE_MIN = 0;//minimum column/row value
const int SQUARE_MAX = 2;//maximum column/row value

/**
 * object for spaces inside of game board
*/
struct Space{
    int row;//row value 
    int column;//column value
    char piece;//piece value
    bool isChoiceValid(int choice);//tests choice validity
};

/**
 * object for game general
*/
struct Game{
    array<array<char,LEN>,LEN> board{{{' ',' ',' '},{' ',' ',' '},{' ',' ',' '}}};//initialize board with space in each value
    array<string,8> getSets();//all possible win sets
    Space askChoice();//gets space choice
    bool isGameOver();//determines if game is over or not
    string whoIsWinner();//determines winner of game
    void takeTurn(char player);//runs turn functions
    bool isSpaceOpen(Space current_space);//checks if space is open on the board
    void takeSpace(Space current_space);//takes a space on the board
    void printBoard();//prints board
};

void dispTitle();
int getInt();

/**
 * Author: David Hatcher
 * Purpose: This program allows the user to play a two player game a tic tac toe.
*/
int main(){
    dispTitle();// display title
    Game current_game;//initialize game
    int turn_counter = 0;//turn counter
    current_game.printBoard();
    while(!current_game.isGameOver()){//check if game is over
        char current_player = (turn_counter++ % 2 == 0) ? 'X' : 'O';//swaps players based on turn counter
        current_game.takeTurn(current_player);//initiate turn chices
        current_game.printBoard();//print board after turn has been taken
        if(turn_counter == 9){ //game over, must be winner or cats game
            break;
        }
    }
    cout << current_game.whoIsWinner() << endl << endl << "Game Over!";//displays winner and game over
    return 0;
}

/**
 * getSets() game member function gets all the possible
 * rows,columns, and diagonals that can create a win
*/
array<string,8> Game::getSets(){
    //initialize strings for different sets
    string set,set_diag_down = "",set_diag_up = "",set_col_1 = "",set_col_2 = "",set_col_3 = "";
    array<string,8> sets;//array of winnable sets
    int i = 0;
    for(unsigned int r = 0; r < board.size(); ++r){
        set = "";
        for(unsigned int c = 0; c < board[r].size(); ++c){
            if(r == c){//this is for diagonal downward
                set_diag_down += board[r][c];
            }
            if(r + c == 2){//this is for diagonal upward
                set_diag_up += board[r][c];
            }
            //this conditional creates column sets
            if(c == 0){
                set_col_1 += board[r][c];
            }else if(c == 1){
                set_col_2 += board[r][c];
            }
            else{
                set_col_3 += board[r][c];
            }
            //row set
            set += board[r][c];
        }
        //add row set to sets array
        sets[i++] = set;
    }
    //adds other sets to sets array
    sets[i++] = set_col_1;
    sets[i++] = set_col_2;
    sets[i++] = set_col_3;
    sets[i++] = set_diag_down;
    sets[i++] = set_diag_up;
    return sets;
}

/**
 * isGameOver game member function determines if the game is over
*/
bool Game::isGameOver(){
    array<string,8> sets = getSets();
    for(unsigned int j = 0; j < sets.size(); ++j){
        if(sets[j] ==  X_WINS || sets[j] == O_WINS){
            return true;
        }
    }
    return false;
}

/**
 * whoIsWinner game member function checks the current board and determines the winner
*/
string Game::whoIsWinner(){
    array<string,8> sets = getSets();
    for(unsigned int j = 0; j < sets.size(); ++j){
        if(sets[j] ==  X_WINS){
            return "X Wins!";
        }else if(sets[j] == O_WINS){
            return "O Wins!";
        }
    }
    return "Cat's Game!";//if theres no winner
}

/**
 * takeTurn game member function takes a player character runs each players turn
*/
void Game::takeTurn(char player){
        cout << player << "'s Turn!" << endl << endl;
        Space current_space = askChoice();
        current_space.piece = player;
        while(!isSpaceOpen(current_space)){
            cout << "Space is taken please select again" << endl;
            current_space = askChoice();
            current_space.piece = player;
        }
        takeSpace(current_space);
}

/**
 * isSpaceOpen game member function takes a space object and checks if the space is open
*/
bool Game::isSpaceOpen(Space current_space){
    if(board[current_space.row][current_space.column] == 'X' || board[current_space.row][current_space.column] == 'O'){
        return false;
    }
    return true;
}

/**
 * takeSpace game member function takes a space object and puts the piece in that space
*/
void Game::takeSpace(Space current_space){
    board[current_space.row][current_space.column] = current_space.piece;
}

/**
 * printBoard game member function prints the current board state
*/
void Game::printBoard(){
    for(unsigned int r = 0; r < board.size(); ++r){
        cout << endl << "+---+---+---+" << endl << "| ";
        for(unsigned int c = 0; c < board[r].size(); ++c){
            cout << board[r][c] << " | ";
        }
    }
    cout << endl << "+---+---+---+" << endl;
}

/**
 * isChoiceValid space member function takes in an int and determines
 * if that space is a valid choice
*/
bool Space::isChoiceValid(int choice){
    if(choice > SQUARE_MAX || choice < SQUARE_MIN){
        return false;
    }
    return true;
}

/**
 * askChoice game member function asks the user a row and column value
 * determines if it's valid and then returns a space object containing 
 * those values
*/
Space Game::askChoice(){
    string row_choice = "Pick a row (1,2,3): ";
    string column_choice = "Pick a column (1,2,3): ";
    string invalid_choice = "Invalid please enter 1, 2 or 3.";
    Space current_space;
    cout << endl << row_choice;
    int row_val = getInt() - 1;//subtract 1 to align with array indices
    while(!current_space.isChoiceValid(row_val)){//check if the choice is valid
        cout << invalid_choice << endl;
        cout << endl << row_choice;
        row_val = getInt() - 1;//subtract 1 to align with array indices
    }
    cout << endl << column_choice;
    int column_val = getInt() - 1;//subtract 1 to align with array indices
    while(!current_space.isChoiceValid(column_val)){//check if the choice is valid
        cout << invalid_choice << endl;
        cout << endl << column_choice;
        column_val = getInt() - 1;//subtract 1 to align with array indices
    }
    //set values on space object
    current_space.row = row_val;
    current_space.column = column_val;
    return current_space;
}

/**
 * dispTitle function displays the title
*/
void dispTitle(){
    cout << "Welcome to Tic Tac Toe" << endl << endl;
}

/**
 * getInt function gets an integer from the user,
 * checks for validity of input as well
*/
int getInt(){
    int value;
    cin >> value;
    if(cin.good()){
        cin.ignore(numeric_limits<streamsize>::max(),'\n');
        return value;
    }else{
        cout << endl << "Value must be a number, please try again: ";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(),'\n');
        return getInt();
    }
}