#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>

const std::string menu_file_name = "menu.txt";


using namespace std;

/**
 * MenuItem struct is a container for a single menu item
*/
struct MenuItem{
    string name = "";
    int price = 0;
    string day = "";
};

vector<MenuItem> getMenuItems(const string file_name);
void dispTitle();
void dispCommands();
string getDay();
void printMenuItems(const string day, const vector<MenuItem> items);
bool isDayValid(const string day,const vector<string> days);
void invalidCommand();

/**
 * Author: David Hatcher
 * Purpose: This program will read in a tab delimited text file and
 * allow the user to type in a day of the week and it will then display that
 * days menu
*/
int main(){
    vector<MenuItem> items = getMenuItems(menu_file_name);
    vector<string> days = {"sun","mon","tue","wed","thu","fri","sat"};
    dispTitle();
    dispCommands();
    bool run_flag = true;//for determining if the loop should keep going
    do{
        string day = getDay();
        if(day == "exit"){//if exit end loop
            run_flag = false;
        }else{
            if(isDayValid(day,days)){//check validity of day
                printMenuItems(day,items);            
            }else{//if not valid run invalidCommand
                invalidCommand();
            }
        }
    }while(run_flag);
    cout << "Bye!";
}

/**
 * getMenuItems function takes a string file name and
 * reads values in from that file, using those files to
 * build MenuItem objects then returns a vector of all
 * MenuItems
*/
vector<MenuItem> getMenuItems(const string file_name){    
    vector<MenuItem> items;
    string line;
    ifstream input_file;
    input_file.open(file_name);    
    while(getline(input_file,line)){
        stringstream ss(line);
        string substr;
        MenuItem item;
        string intHolder;
        getline(ss,item.name,'\t');//grab from until first tab
        getline(ss,intHolder,'\t');//grab from until next tab
        ss >> item.day;//grab rest as the ending is newline
        item.price = stoi(intHolder);///convert the string to int
        items.push_back(item);
    }
    input_file.close();
    return items;
}

/**
 * dispTitle function displays the title
*/
void dispTitle(){
    cout << "Menu of the Day" << endl << endl;
}

/**
 * dispCommands function display the commands
*/
void dispCommands(){
    cout << "Specify the day using the three-letter format" << endl
    << "(mon, tue, wed, thu, fri, sat, sun)." << "Or, enter 'exit' to exit." << endl;
}

/**
 * getDay function asks the user to enter a day then returns a string
*/
string getDay(){
    cout << "Day: ";
    string response;
    cin >> response;
    for(unsigned int i = 0; i < response.length(); i++){
        response[i] = tolower(response[i]);
    }
    return response;
}

/**
 * printMenuItems takes a string day and a vector of menu items then 
 * prints out menu items that match the day string
*/
void printMenuItems(const string day, const vector<MenuItem> items){
    for(MenuItem i: items){
        if(day == i.day){
            cout << setw(20) << left << i.name << setw(8) << right << i.price << endl;
        }
    }
    cout << left << endl;
}

/**
 * isDayValid function takes a string day and a vector of days
 * and determines if the day is valid
*/
bool isDayValid(const string day,const vector<string> days){
    for(string d : days){
        if(d == day){
            return true;
        }
    }
    return false;
}

/**
 * invalidCommand lets the user know they entered an invalid command
*/
void invalidCommand(){
    cout << "Invalid day" << endl << endl;
}
